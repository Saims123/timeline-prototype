"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var sample_objects_service_1 = require("./sample-objects.service");
describe('SampleObjectsService', function () {
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({
            providers: [sample_objects_service_1.SampleObjectsService]
        });
    });
    it('should be created', testing_1.inject([sample_objects_service_1.SampleObjectsService], function (service) {
        expect(service).toBeTruthy();
    }));
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FtcGxlLW9iamVjdHMuc2VydmljZS5zcGVjLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2FtcGxlLW9iamVjdHMuc2VydmljZS5zcGVjLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsaURBQXdEO0FBRXhELG1FQUFnRTtBQUVoRSxRQUFRLENBQUMsc0JBQXNCLEVBQUU7SUFDL0IsVUFBVSxDQUFDO1FBQ1QsaUJBQU8sQ0FBQyxzQkFBc0IsQ0FBQztZQUM3QixTQUFTLEVBQUUsQ0FBQyw2Q0FBb0IsQ0FBQztTQUNsQyxDQUFDLENBQUM7SUFDTCxDQUFDLENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQyxtQkFBbUIsRUFBRSxnQkFBTSxDQUFDLENBQUMsNkNBQW9CLENBQUMsRUFBRSxVQUFDLE9BQTZCO1FBQ25GLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMifQ==
import { Component, OnInit, NgModule, VERSION} from '@angular/core';
import { SampleTimeLineObjectsService } from '../timeline-objects/sample-objects.service';



@Component({
  selector: 'app-timeline-playground',
  templateUrl: './timeline-playground.component.html',
  styleUrls: ['./timeline-playground.component.css']
})
export class TimelinePlaygroundComponent implements OnInit {

  constructor(private sample: SampleTimeLineObjectsService) {
  }

  ngOnInit() {
  }

}
